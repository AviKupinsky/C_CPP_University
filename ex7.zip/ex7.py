#############################################################
# FILE : ex.7
# WRITER : Avi Kupinsky avikupinsky 318336070
# EXERCISE : intro2cs1  ex7 2021
#############################################################
from typing import List, Any
from ex7_helper import *


def mult(x: float, y: int) -> float:
    """
    in this function we use recursion in order to mult
    :param x:num
    :param y:num
    :return: the mul of x and y
    """
    if y == 0:
        return 0
    return add(x, 0) + mult(x, subtract_1(y))


def is_even(n: int) -> bool:
    """
    in this function we find out throw recursion if
    the num is even or not
    :param n: num
    :return: True are False
    """
    if n == 1:
        return False
    if n == 0:
        return True
    new1 = subtract_1(n)
    new2 = subtract_1(new1)
    return is_even(new2)


def log_mult(x: float, y: int) -> float:
    """
    in this function we use recursion in order to mult runtime of log
    :param x:num
    :param y:num
    :return: the mul of x and y
    """
    if y == 0:
        return 0
    if y == 1:
        return x
    temp1 = add(x, x)
    temp2 = divide_by_2(y)
    if not is_odd(y):
        return log_mult(temp1, temp2)
    else:
        return add(x, log_mult(temp1, temp2))


def is_power(b: int, x: int) -> bool:
    """
    in this function we find if the power is of x can be with b enugh time
    :param b:num
    :param x:num
    :return:True are False
    """
    if x == 1 or x == b:
        return True
    elif b == 1 or b > x or b == 0:
        return False
    else:
        new_b = b
        return helper_is_power(b, x, new_b)


def helper_is_power(b: int, x: int, newb: int) -> bool:
    """
    a function that helps with the power function
    :param b: changing_b
    :param x: num
    :param newb: old_b
    :return: True are False
    """
    if b == x:
        return True
    elif b > x:
        return False
    else:
        change_b = int(mult(b, newb))
        return helper_is_power(change_b, x, newb)


def reverse(s: str) -> str:
    """
    in this function we revers the str we have got
    :param s: str
    :return: a reverse str
    """
    if s == '':
        return s
    count = subtract_1(len(s))
    new_str = s[count]
    last = helper_revers(s, new_str, count)
    return last


def helper_revers(s: str, new_str: str, count: int) -> str:
    """
    a function to help the revers
    :param s: original str
    :param new_str: one str
    :param count: num
    :return: the combination of the str
    """
    if count < 0:
        return ""
    count = subtract_1(count)
    return new_str + helper_revers(s, s[count], count)


def play_hanoi(Hanoi: Any, n: int, src: Any, dst: Any, temp: Any) -> Any:
    """
    The function plays the game of hanoi tower based on the number
     of disc that it has it should know how to organize it.
    :param Hanoi: The graphic of the game
    :param n: a number
    :param src: a poll where the disc are in the beginning of the game
    :param dst: a poll where the disc are in the end of the game
    :param temp: a poll to use during the game
    :return: The graphic of the game how it should be plated
    """
    try:
        if n == 1:
            Hanoi.move(src, dst)
            return Hanoi
        else:
            play_hanoi(Hanoi, n - 1, src, temp, dst)
            Hanoi.move(src, dst)
            play_hanoi(Hanoi, n - 1, temp, dst, src)
    except:
        return


def helper_number_of_ones(n: int) -> int:
    """
    another helper wo find how many digits there is
    :param n: int
    :return: the amount of digits
    """
    if n == 0:
        return 1
    return 10 * helper_number_of_ones(n//10)


def last_helper(n: int) -> int:
    """
    this function is the lat helper
    :param n: int
    :return: the amount of 1
    """
    count = helper_number_of_ones(n // 10)
    if n == 1:
        return 1
    if count == 1:
        return 0
    if n % 10 != 1:
        if n//count == 1:
            return 1 + last_helper(n % count)
        else:
            return last_helper(n % count)
    return 0


def number_of_ones(n: int) -> int:
    """
    in this function we find how many times 1 appears
    :param n:int
    :return:num of ones
    """
    if n == 1:
        return 1
    if n == 0:
        return 0
    count = helper_number_of_ones(n // 10)
    if count == 1:
        return number_of_ones(n-1)
    if n % 10 != 1:
        if n//count == 1:
            return 1 + last_helper(n % count) + number_of_ones(n-1)
        else:
            return last_helper(n % count) + number_of_ones(n-1)
    elif n % 10 == 1:
        return 1 + last_helper(n // count) + number_of_ones(n-1)
    return 0


def compare_2d_lists(l1: List[List[int]], l2: List[List[int]]) -> bool:
    """
    in this function we compare between the lists
    :param l1: list
    :param l2: list
    :return: True are False
    """
    if l1 == [[]] and l2 == [[]]:
        return True
    if len(l1) != len(l2):
        return False
    return helper_compare_2d_lists(l1, l2, len(l1), 0)


def helper_compare_2d_lists(l1: List[List[int]], l2: List[List[int]], num: int, count: int) -> bool:
    """
    its a function to help the compare 2d function
    :param l1: list
    :param l2: list
    :param num: int
    :param count: int
    :return: True are False
    """
    if count == num:
        return True
    len(l1[count])
    new_l1 = l1[count]
    new_l2 = l2[count]
    return (helper_compare_2d_lists(l1, l2, num, count + 1)
            and another_helper_campare_2d_lists(new_l1, new_l2, len(l1[count]), 0))


def another_helper_campare_2d_lists(l1: List[int], l2: List[int], num: int, count: int) -> bool:
    """
    another helper
    :param l1: list
    :param l2: list
    :param num: int
    :param count: int
    :return: True are False
    """
    if len(l1) != len(l2):
        return False
    if num == count:
        return True
    return (l1[count] == l2[count]) and another_helper_campare_2d_lists(l1, l2, num, count+1)


def magic_list(n: int) -> List[Any]:
    """
    in this function we based on the number get all the list we can ger
    :param n: nam
    :return: all the possibilities of the list
    """
    if n == 0:
        return []
    list = magic_list(n-1)
    list.append(magic_list(n-1))
    return list



