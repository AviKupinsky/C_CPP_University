import math

def golden_ratio():
    print((1+math.sqrt(5))/2)

def six_squared():
    print(math.pow(6,2))

def hypotenuse():
    print(math.sqrt(math.pow(5,2)+math.pow(12,2)))

def pi():
    print(math.pi)

def e():
    print(math.e)

def squares_area():
    print(1*1,2*2,3*3,4*4,5*5,6*6,7*7,8*8,9*9,10*10)



if __name__ == "__main__":
    golden_ratio()
    six_squared()
    hypotenuse()
    pi()
    e()
    squares_area()

