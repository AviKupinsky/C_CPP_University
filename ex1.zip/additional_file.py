def secret_function():
    print('My username is avikupinsky and I know I must read the submission response.')

if __name__ == "__main__":
    secret_function()