import helper
from board import*
from car import*
import sys


class Game:
    """
    Add class description here
    """
    def __init__(self, board):
        """
        Initialize a new Game object.
        :param board: An object of type board
        """
        self.board = board

    def __single_turn(self):
        """
        The function runs one round of the game :
            1. Get user's input of: what color car to move, and what 
                direction to move it.
            2. Check if the input is valid.
            3. Try moving car according to user's input.

        Before and after every stage of a turn, you may print additional 
        information for the user, e.g., printing the board. In particular,
        you may support additional features, (e.g., hints) as long as they
        don't interfere with the API.
        """
        answer = ''
        while answer != '!':
            possibilieties = self.board.possible_moves()
            print(possibilieties)
            answer = input("what car would you like to move?, and where would you like to move it to ")
            if answer == '!':
                continue
            else:
                x = answer[1]
                y = answer[3]
                if x not in ["Y", "R", "B", "O", "G", "W"]:
                    print("there isn't a car with the name you have given, please try again ")
                elif y not in ["r", "l", "d", "u"]:
                    print("there isn't the option you have given, try again ")
                items = []
                for i in possibilieties:
                    items.append((i[0], i[1]))
                if (x, y) not in items:
                    print("You have entered the wrong coordination, pleas try again ")
                else:
                    self.board.move_car(x, y)
                    print(self.board)
                    if self.board.cell_content((self.board.target_location())) is not None:
                        return True

        else:
            print("Hope you enjoyed the game")
            exit()

    def play(self):
        """
        The main driver of the Game. Manages the game until completion.
        :return: None
        """
        print("lets start playing rush-hour, here is the board you will be playing."
              " The goal is to get with one of the cars to the finish line where its marked E")
        print(self.board)
        while self.__single_turn() is not True:
            self.__single_turn()
        else:
            print("You have beaten the game, congratulations")


if __name__ == "__main__":
    board1 = Board()
    car_config = helper.load_json(sys.argv[1])
    for car in car_config:
        if car_config[car][0] < 2 or car_config[car][0] > 4:
            continue
        elif car not in ["Y", "R", "B", "O", "G", "W"]:
            continue
        else:
            board1.add_car(Car(car, car_config[car][0], car_config[car][1], car_config[car][2]))
    game = Game(board1)
    game.play()
