class Board:
    """
    Add a class description here.
    Write briefly about the purpose of the class
    """

    def __init__(self):
        self.__ROW = 7
        self.__COL = 7
        self.__cars = []
        self.__board_matrix = []
        for i in range(self.__ROW):
            if i == 3:
                row = ["_ "] * self.__COL
                row.append("E")
            else:
                row = ["_ "] * self.__COL
            self.__board_matrix.append(row)

    def __upgrating_matrix(self):
        """
        This function we upgrate the litts baset on the cars we have
        :return: A string with all the cars we have
        """
        new_matrix = []
        for i in range(self.__ROW):
            if i == 3:
                row = ["_ "] * self.__COL
                row.append("E")
            else:
                row = ["_ "] * self.__COL
            new_matrix.append(row)
        crs_dict = []
        for i in self.__cars:
            new = i.car_coordinates()
            crs_dict.append((i.get_name(), new))

        for item in crs_dict:
            for coord in item[1]:
                new_matrix[coord[0]][coord[1]] = item[0]
        return new_matrix

    def __str__(self):
        """
        This function is called when a board object is to be printed.
        :return: A string of the current status of the board
        """
        new_matrix = self.__upgrating_matrix()
        string = ''
        for i in range(self.__ROW):
            if i == 3:
                for j in range(8):
                    if new_matrix[i][j] != "_ ":
                        string += new_matrix[i][j] + " "
                    else:
                        string += new_matrix[i][j]
            else:
                for j in range(self.__COL):
                    if new_matrix[i][j] != "_ ":
                        string += new_matrix[i][j] + " "
                    else:
                        string += new_matrix[i][j]
            string += "\n"

        return string

    def cell_list(self):
        """ This function returns the coordinates of cells in this board
        :return: list of coordinates
        """
        main_list = []
        lst1 = []
        lst2 = []
        for i in range(self.__ROW):
            lst1.append(i)
        for i in range(self.__COL):
            lst2.append(i)
        for i in lst2:
            for j in lst2:
                main_list.append((i, j))
        main_list.append((3, 7))
        return main_list

    def possible_moves(self):
        """ This function returns the legal moves of all cars in this board
        :return: list of tuples of the form (name,movekey,description) 
                 representing legal moves
        """
        list_expration = []
        for car in self.__cars:
            if car.possible_moves() == {'d': "it moves the care 1 move down",
                                            'u': "it moves the care 1 move up"}:
                description1 = (car.get_name(), 'u', "the car cane move up")
                description2 = (car.get_name(), 'd', "the car cane move down")
                if car.location[0] > 0:
                    new_1 = car.movement_requirements("u")
                    for i in new_1:
                        if self.cell_content(i) is None:
                            list_expration.append(description1)
                if car.location[0] <= 6:
                    new_2 = car.movement_requirements("d")
                    for i in new_2:
                        if self.cell_content(i) is None:
                            list_expration.append(description2)
            elif car.possible_moves() == {'l': "it moves the care 1 move to the left",
                                            'r': "it moves the care 1 move to the right"}:
                description3 = (car.get_name(), 'r', "the car cane move right")
                description4 = (car.get_name(), 'l', "the car cane move left")
                if car.location == (3, 6):
                    list_expration.append(description3)
                    new_4 = car.movement_requirements("l")
                    for i in new_4:
                        if self.cell_content(i) is None:
                            list_expration.append(description4)
                if car.location[1] <= 5:
                    new_3 = car.movement_requirements("r")
                    for i in new_3:
                        if self.cell_content(i) is None:
                            list_expration.append(description3)
                if car.location[1] > 0:
                    new_4 = car.movement_requirements("l")
                    for i in new_4:
                        if self.cell_content(i) is None:
                            list_expration.append(description4)
        return list_expration

    def target_location(self):
        """
        This function returns the coordinates of the location which is to be filled for victory.
        :return: (row,col) of goal location
        """
        return 3, 7

    def cell_content(self, coordinate):
        """
        Checks if the given coordinates are empty.
        :param coordinate: tuple of (row,col) of the coordinate to check
        :return: The name if the car in coordinate, None if empty
        """
        if coordinate not in self.cell_list():
            return None
        another_lst = self.__upgrating_matrix()
        if coordinate == (3, 7):
            if another_lst[coordinate[0]][coordinate[1]] == 'E':
                return None
            else:
                return another_lst[coordinate[0]][coordinate[1]]
        elif another_lst[coordinate[0]][coordinate[1]] != '_ ':
            return another_lst[coordinate[0]][coordinate[1]]
        else:
            return None

    def add_car(self, car):
        """
        Adds a car to the game.
        :param car: car object of car to add
        :return: True upon success. False if failed
        """
        new_matrix = self.__upgrating_matrix()
        coordination = car.car_coordinates()
        if car in self.__cars:
            return False
        for i in new_matrix:
            for j in i:
                if car.get_name() == j:
                    return False
        location = coordination[0]
        if location[0] < 0 or location[1] < 0:
             return False
        for i in car.car_coordinates():
             if i not in self.cell_list():
                 return False
        for i in coordination:
            if new_matrix[i[0]][i[1]] != '_ ':
                return False
        else:
            self.__cars.append(car)
            return True

    def move_car(self, name, movekey):
        """
        moves car one step in given direction.
        :param name: name of the car to move
        :param movekey: Key of move in car to activate
        :return: True upon success, False otherwise
        """
        lst = []
        if self.__cars == []:
            return False
        for i in self.__cars:
            lst.append(i.get_name())
        if name not in lst:
            return False
        else:
            for i in self.__cars:
                if i.get_name() == name:
                    for j in i.movement_requirements(movekey):
                        if movekey == "u":
                            if j[0] < 0:
                                return False
                            if self.cell_content(j) is not None:
                                return False
                        if movekey == "d":
                            if j[0] > 6:
                                return False
                            if self.cell_content(j) is not None:
                                return False
                        if movekey == "r":
                            if j[0] == 3:
                                if j[1] > 7:
                                    return False
                            else:
                                if j[1] > 6:
                                    return False
                            if self.cell_content(j) is not None:
                                return False
                        if movekey == "l":
                            if j[1] < 0:
                                return False
                            if self.cell_content(j) is not None:
                                return False
                            else:
                                i.move(movekey)
                                self.__upgrating_matrix()
                                return True
                        else:
                            i.move(movekey)
                            self.__upgrating_matrix()
                            return True


