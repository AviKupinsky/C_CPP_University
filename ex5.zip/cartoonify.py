#############################################################
# FILE : cartoonify.py
# WRITER : Avi Kupinsky avikupinsky 318336070
# EXERCISE : intro2cs1  ex 5 2021
#############################################################

import sys
from ex5_helper import *
from math import *
import copy

MUL_RED = 0.299
MUL_GREEN = 0.587
MUL_BLUE = 0.114
NUM_ZERO = 0
OVER_FLOW = 255


def separate_channels(image):
    """
    in this function we are separating the channels into there own lists
    :param image:
    :return: a list of channels
    """
    head_list = []
    for i in range(len(image[0][0])):
        new_list = []
        for j in range(len(image)):
            new_new_list = []
            for k in range(len(image[0])):
                new_new_list.append(image[j][k][i])
            new_list.append(new_new_list)
        head_list.append(new_list)
    return head_list


def combine_channels(channels):
    """
    in this function we are commanding the channels
    :param channels:
    :return: a list of channels combined
    """
    head_list = []
    for i in range(len(channels[0])):
        new_list = []
        for j in range(len(channels[0][0])):
            new_new_list = []
            for k in range(len(channels)):
                new_new_list.append(channels[k][i][j])
            new_list.append(new_new_list)
        head_list.append(new_list)
    return head_list


def RGB2grayscale(colored_image):
    """
    in this function were calculating the pictures colors into white and black
    :param colored_image: a list of a image
    :return:white and black version of the image.
    """
    head_list = []
    for i in range(len(colored_image)):
        new_list = []
        for j in range(len(colored_image[0])):
            new_list.append(round((colored_image[i][j][0] * MUL_RED)
                                  + (colored_image[i][j][1] * MUL_GREEN)
                                  + (colored_image[i][j][2] * MUL_BLUE)))
        head_list.append(new_list)
    return head_list


def blur_kernel(size):
    """
    in this function we get a number and create a list based on the number we got of 1//num nu, times
    :param size: number
    :return: a blur kernel list
    """
    head_list = []
    Squared_size = size ** 2
    for i in range(abs(size)):
        new_list = []
        for j in range(abs(size)):
            new_list.append((1 / Squared_size))
        head_list.append(new_list)
    return head_list


def calculating_function_apply_kernel(rows, colm, kernel, image):
    """
    in this function we calculating between the the image and kernel based if there is a row and col that we asked
    :param rows: the num of rows
    :param colm: the num of colm
    :param kernel: a list of blur_kernel
    :param image: a list of the image
    :return: a list after the calculation we made
    """
    num = 0
    length_row = len(image) - 1
    length_col = len(image[0]) - 1
    count1 = len(kernel) // 2
    for i in range(len(kernel)):
        count2 = len(kernel) // 2
        for j in range(len(kernel[0])):
            if 0 <= rows - count1 <= length_row and 0 <= colm - count2 <= length_col:
                num += image[rows - count1][colm - count2] * kernel[i][j]
            else:
                num += image[rows][colm] * kernel[i][j]
            count2 -= 1
        count1 -= 1
    if num < NUM_ZERO:
        num = NUM_ZERO
    if num > OVER_FLOW:
        num = OVER_FLOW
    return round(num)


def apply_kernel(image, kernel):
    """
    in this function we apply the kennel into the list
    :param image: a list of the image
    :param kernel: a num that we want ti blur
    :return: a new image that was kernel
    """
    changin_image = copy.deepcopy(image)
    for i in range(len(image)):
        for j in range(len(image[0])):
            changin_image[i][j] = calculating_function_apply_kernel(i, j, kernel, image)
    return changin_image


def bilinear_interpolation(image, y, x):
    """
    in this function were calculting the image based on what x and y are
    :param image: a list of the image
    :param y: num
    :param x: num
    :return: a new_list after the calculation
    """
    a = image[0][0]
    b = image[0][1]
    c = image[1][0]
    d = image[1][1]
    if x > 1:
        x = 1
    if y > 1:
        y = 1
    if x < NUM_ZERO:
        x = NUM_ZERO
    if y < NUM_ZERO:
        y = NUM_ZERO
    sub1 = a * (1 - y) * (1 - x)
    sub2 = b * x * (1 - y)
    sub3 = c * y * (1 - x)
    sub4 = d * x * y
    changing_image = round(sub1 + sub2 + sub3 + sub4)
    if changing_image > OVER_FLOW:
        changing_image = OVER_FLOW
    elif changing_image < NUM_ZERO:
        changing_image = NUM_ZERO
    return changing_image


def creating_List(num1, num2):
    """
    in this function we create a list on the number we gat
    :param num1: number
    :param num2: number
    :return: a list based on the numbers
    """
    head_list = []
    count1 = 0
    while count1 != num1:
        count = 0
        new_list = []
        while count != num2:
            new_list.append(0)
            count += 1
        head_list.append(new_list)
        count1 += 1
    return head_list


def resize(image, new_height, new_width):
    """
    in this function were resigning the image based on the hight and width we got
    :param image: a list of the image
    :param new_height: num
    :param new_width: num
    :return: a new_list after the calculation
    """
    head_list = creating_List(new_height, new_width)
    len_rows = len(image)
    len_colm = len(image[0])
    if new_width > 1:
        new_x = float(len_colm - 1) / (new_width - 1)
    else:
        new_x = 1
    if new_height > 0:
        new_y = float(len_rows - 1) / (new_height - 1)
    else:
        new_y = 0
    if type(new_width) == float:
        new_width = round(new_width)
    for i in range(new_height):
        for j in range(new_width):
            x1 = floor(new_x*j)
            y1 = floor(new_y*i)
            x2 = ceil(new_x*j)
            y2 = ceil(new_y * i)
            num1 = (new_x*j) - x1
            num2 = (new_y*i) - y1
            new_list = [[image[y1][x1], image[y1][x2]], [image[y2][x1], image[y2][x2]]]
            head_list[i][j] = bilinear_interpolation(new_list, num2, num1)
    return head_list


def rotate_90(image, direction):
    """
    in this function we change the image list right are left
    :param image: a list of the image
    :param direction: "R" are "L"
    :return: a new_list after the calculation
    """
    head_list = []
    if direction == "R":
        changing_image = image[::-1]
        for i in range(len(changing_image[0])):
            new_list = []
            for j in range(len(changing_image)):
                new_list.append(changing_image[j][i])
            head_list.append(new_list)
    elif direction == "L":
        count = (len(image[0]) - 1)
        while count >= 0:
            new_list = []
            for i in range(len(image)):
                new_list.append(image[i][count])
            head_list.append(new_list)
            count -= 1
    return head_list



def new_calculating_function_apply_kernel(rows, colm, kernel, image):
    """
    in this function we calculating between the the image and kernel based if there is a row and col that we asked
    :param rows: the num of rows
    :param colm: the num of colm
    :param kernel: a list of blur_kernel
    :param image: a list of the image
    :return: a list after the calculation we made
    """
    num = 0
    length_row = len(image) - 1
    length_col = len(image[0]) - 1
    count1 = len(kernel) // 2
    for i in range(len(kernel)):
        count2 = len(kernel) // 2
        for j in range(len(kernel[0])):
            if 0 <= rows - count1 <= length_row and 0 <= colm - count2 <= length_col:
                num += image[rows - count1][colm - count2] * kernel[i][j]
            else:
                num += image[rows][colm] * kernel[i][j]
            count2 -= 1
        count1 -= 1
    return num


def get_edges(image, blur_size, block_size, c):
    """
    in this function we get a blur_image and a threshol and cacultin between them
    :param image: a list of the image
    :param blur_size:num
    :param block_size:num
    :param c:num
    :return: a new_list after the calculation
    """
    blur_image = apply_kernel(image, blur_kernel(blur_size))
    final_image = copy.deepcopy(blur_image)
    for i in range(len(blur_image)):
        for j in range(len(blur_image[0])):
            changing_image = new_calculating_function_apply_kernel(i, j, blur_kernel(block_size), blur_image)
            if changing_image - c > blur_image[i][j]:
                final_image[i][j] = NUM_ZERO
            else:
                final_image[i][j] = OVER_FLOW
    return final_image


def quantize(image, N):
    """
    in this function we create the list_quantize based on the n we have
    :param image: a list of the image 2d list
    :param N:num
    :return: a new_list after the calculation
    """
    final_image = copy.deepcopy(image)
    for i in range(len(image)):
        for j in range(len(image[0])):
            final_image[i][j] = round(floor(image[i][j] * (N / 255)) * (255 / N))
    return final_image


def quantize_colored_image(image, N):
    """
    in this function we create the list_quantize based on the n we have
    :param image: a list of the image 3d list
    :param N:num
    :return: a new_list after the calculation
    """
    final_image = copy.deepcopy(image)
    for i in range(len(image)):
        final_image[i] = quantize(image[i], N)
    return final_image


def add_mask(image1, image2, mask):
    """
    in this function we add between image's
    :param image1:  a list of the image
    :param image2:  a list of the image
    :param mask: a list between 0 and 1
    :return: a new_list after the calculation
    """
    changing_image = copy.deepcopy(image1)
    if isinstance(image1[0][0], list):
        for i in range(len(image1)):
            for j in range(len(image1[0])):
                for k in range(len(image1[0][0])):
                    changing_image[i][j][k] = round((image1[i][j][k] * mask[i][j]) + (image2[i][j][k] * (1 - mask[i][j])))
    else:
        for i in range(len(image1)):
            for j in range(len(image1[0])):
                changing_image[i][j] = round((image1[i][j] * mask[i][j]) + (image2[i][j] * (1 - mask[i][j])))
    return changing_image



def cartoonify(image, blur_size, th_block_size, th_c, quant_num_shades):
    """
    in this function we cartoonify the image based on function we had in the past
    :param image: a list of the image
    :param blur_size: num
    :param th_block_size: num
    :param th_c: num
    :param quant_num_shades: num
    :return: the cartoonify image
    """
    head_image = copy.deepcopy(image)
    sparate_image = RGB2grayscale(image)
    new_image = get_edges(sparate_image, blur_size, th_block_size, th_c)
    last = quantize_colored_image(image,quant_num_shades)
    for i in range(len(new_image)):
        for j in range(len(new_image[0])):
            for k in range(len(image[0][0])):
                if new_image[i][j] == 0:
                    head_image[i][j][k] = 0
                else:
                    head_image[i][j][k] = last[i][j][k]
    return head_image


if __name__ == '__main__':
    check = len(sys.argv)
    if check != 8:
        print("there isn't enough arguments")
        exit(0)
    new = load_image(sys.argv[1])
    size = int(sys.argv[3])
    new_image = cartoonify(new, int(sys.argv[4]), int(sys.argv[5]), int(sys.argv[6]), int(sys.argv[7]))
    save_image(new_image, sys.argv[2])

