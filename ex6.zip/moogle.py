#############################################################
# FILE :
# WRITER : Avi Kupinsky avikupinsky 318336070
# EXERCISE : intro2cs1  ex 6 2021
#############################################################

import pickle
import requests
import urllib.parse
import sys
from bs4 import *


def creating_dictionary_website():
    """
    in this function we create a dictionary to check how many website are in a page"
    """
    file = open(sys.argv[3], "r")
    lines = file.readlines()
    first_dict = {}
    for line in lines:
        line_strip = line.strip()
        base_url = sys.argv[2]
        first_dict[line_strip] = {}
        relative_url = line_strip
        full_url = urllib.parse.urljoin(base_url, relative_url)
        response = requests.get(full_url)
        soup = BeautifulSoup(response.text, 'html.parser')
        for new_line in lines:
            new = new_line.strip()
            count = 0
            for p in soup.find_all("p"):
                for link in p.find_all("a"):
                    target = link.get("href")
                    if target == new:
                        count += 1
                if count != 0:
                    first_dict[line_strip][new] = count
    with open(sys.argv[4], 'wb') as fd:
        pickle.dump(first_dict, fd)
    file.close()
    fd.close()


def calculating_volume():
    """
    in this function we create a dictionary to to calculate the pages"
    """
    iterations = int(sys.argv[2])
    with open(sys.argv[3], 'rb') as f:
        origin_dict = pickle.load(f)
    new_dict = {}
    for i in origin_dict.keys():
        new_dict[i] = 1
    while iterations != 0:
        new_new_dict = {}
        for i in origin_dict.keys():
            new_new_dict[i] = 0
        for name in origin_dict.keys():
            count = 0
            for new_name in origin_dict[name]:
                count += origin_dict[name][new_name]
            for last_name in origin_dict[name]:
                num = origin_dict[name][last_name]
                new_new_dict[last_name] += (new_dict[name]*(num/count))
        new_dict = new_new_dict
        iterations -= 1
    with open(sys.argv[4], 'wb') as file:
        pickle.dump(new_dict, file)
    f.close()
    file.close()


def creating_dictionary_words():
    """
    in this function we create a dictionary to check how many words are in a page"
    """
    f = open(sys.argv[3], "r")
    lines = f.readlines()
    second_dict = {}
    for line in lines:
        line_strip = line.strip()
        base_url = sys.argv[2]
        relative_url = line_strip
        full_url = urllib.parse.urljoin(base_url, relative_url)
        response = requests.get(full_url)
        soup = BeautifulSoup(response.text, 'html.parser')
        for p in soup.find_all("p"):
            content = p.text
            content = content.split()
            for word in content:
                if word not in second_dict:
                    second_dict[word] = {}
                    second_dict[word][line_strip] = 0
                if line_strip in second_dict[word]:
                    second_dict[word][line_strip] += 1
                else:
                    second_dict[word][line_strip] = 0
                    second_dict[word][line_strip] += 1
    with open(sys.argv[4], 'wb') as file:
        pickle.dump(second_dict, file)
    f.close()
    file.close()


def last_task():
    """
    in this function we print the word that is given with the page
    that the word in mention the minimal times"
    """
    sentence = sys.argv[2]
    sentence = sentence.split()
    num = int(sys.argv[5])
    new_list = []
    with open(sys.argv[3], 'rb') as f:
        page_ranked = pickle.load(f)
    with open(sys.argv[4], 'rb') as fd:
        words_ranked = pickle.load(fd)
    for word in sentence:
        if word not in words_ranked.keys():
            sentence.remove(word)
            continue
        for page in words_ranked[word]:
            if page in page_ranked:
                new_list.append(page)
    head_list = []
    lenght = len(sentence)
    for page in page_ranked.keys():
        if new_list.count(page) == lenght:
            head_list.append(page)
    sorted_page_ranked = sorted(page_ranked.items(), key=lambda kv: kv[1], reverse=True)
    final_list = []
    for new_page in sorted_page_ranked:
        if num == 0:
            break
        if new_page[0] in head_list:
            final_list.append(new_page)
            num -= 1
    last_result = []
    for Y in range(len(final_list)):
        result = []
        for Z in sentence:
            result.append((words_ranked[Z][final_list[Y][0]] * final_list[Y][1]))
        min_num = min(result)
        last_result.append((final_list[Y][0], min_num))
    last_result.sort(key = lambda x: x[1], reverse=True)
    for i in last_result:
        print(i[0], i[1])
    f.close()
    fd.close()


if __name__ == '__main__':
   check = len(sys.argv)
   task = sys.argv[1]
   if task == "crawl":
       if check != 5:
           exit(0)
       creating_dictionary_website()
   elif task == "page_rank":
       if check != 5:
           exit(0)
       calculating_volume()
   elif task == "words_dict":
       if check != 5:
           exit(0)
       creating_dictionary_words()
   elif task == "search":
       if check != 6:
           exit(0)
       last_task()

