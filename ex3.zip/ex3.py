#############################################################
# FILE : ex3.py
# WRITER : Avi Kupinsky avikupinsky 318336070
# EXERCISE : intro2cs ex 3 2021
#############################################################

# In this function we are putting numbers in list and returning then
# in a list including their sum.

def input_list():
    new_list = []  # Creating a list
    """"Threw append were adding a number to the list """
    new_list.append(input())  # Input for adding a number and categorizing it
    """"In the scenario where theres nothing in the string"""
    if new_list[0] == '':
        return [0]
    i = 0
    count = 0
    """"Through a loop were creating what is going to be in the string"""
    while new_list[i] != '':
        new_list.append(input())
        count += float(new_list[i])  # += Adds each time to sum bast on what we put in the input
        new_list[i] = float(new_list[i])
        i = i + 1
    new_list.pop()  # Removing the last space
    new_list.append(count)  # Adding to the last space
    return new_list


# In this function we are taking to lists and from each of them  multipliers their Organs
# with each other


def inner_product(vec_1, vec_2):
    """"When one of the lists are empty"""
    if len(vec_1) == 0 and len(vec_2) == 0:
        return 0
    # When the lists are not equal in their length
    elif len(vec_1) != len(vec_2):
        return None
    else:
        """Creating a loop for the organs to multiply with each other"""
        count = 0
        for i in range(len(vec_1)):
            count += vec_1[i] * vec_2[i]

        return count

# In this function we are creating a list of True and False based on
# if the numbers we give are certain types of series


def sequence_monotonicity(sequence):
    ser1 = True
    ser2 = True
    ser3 = True
    ser4 = True
    """"Putting every single phrase into a loop"""
    for i in range(len(sequence) - 1):
        if not (sequence[i] <= sequence[i + 1]):  # If its a An ascending series or series really comes up
            ser1 = False
    for i in range(len(sequence) - 1):
        if not (sequence[i] < sequence[i + 1]):  # If its only an really comes up series
            ser2 = False
    for i in range(len(sequence) - 1):
        if not (sequence[i + 1] <= sequence[i]):  # if its an descending series or series is really coming down
            ser3 = False
    for i in range(len(sequence) - 1):
        if not (sequence[i + 1] < sequence[i]):  # if its only a series is really coming down
            ser4 = False
    """"Through these loops will know based on the list we give them if its true or false"""

    return[ser1, ser2, ser3, ser4]

# In this function we are checking the opposite
# based on bullets True or False we would like to get the list


def monotonicity_inverse(def_bool):
    """"There are only a few lists that can coexist at the same time"""
    if def_bool == [True, True, False, False]:  # An ascending series or series really comes up
        return [1, 2, 3, 4]
    elif def_bool == [True, False, False, False]:  # only An ascending series
        return [1, 1, 2, 3]
    elif def_bool == [False, False, True, True]:  # An descending series or A series is really coming down
        return [4, 3, 2, 1]
    elif def_bool == [False, False, True, False]:  # only an descending series
        return [4, 4, 3, 2]
    elif def_bool == [True, False, True, False]:  # An ascending series or an descending series
        return [1, 1, 1, 1]
    elif def_bool == [False, False, False, False]:  # there are no series
        return [1, 0, -1, 1]
    else:
        return None


# In this function we are creating a list of prime numbers

def check_if_prime(number):
    """"creating the function of the first primaries number"""
    for j in range(2, int(number ** 0.5) + 1):
        if number % j == 0:
            return False
    return True


# In this function we are creating a list of prime numbers
def primes_for_asafi(n):
    """"Creating a list of only the prime numbers"""
    lists = []
    i = 1
    while len(lists) != n:
        i += 1
        if check_if_prime(i):
            lists.append(i)

    return lists


# In this function we are come binding between lists like vectors
def sum_of_vectors(vec_lst):
    if len(vec_lst) == 0:  # If the list itself is empty
        return None
    else:
        out = []
        for i in range(len(vec_lst[0])):  # Choosing the first list inside the list
            count = 0
            for j in range(len(vec_lst)):  # Choosing the first organ inside the lis
                count += vec_lst[j][i]  # combining every organ with his status from each list
            out.append(count)
        return out


# In this function we are checking if multiplying between lists equals 0
def num_of_orthogonal(vectors):
    """"Receives a list of vectors and by returns the number of pairs
     of lists that are perpendicular to each other"""
    count = 0
    num = 0
    for i in range(len(vectors)):  # Choosing the first list inside the list
        for j in range(len(vectors)):  # Choosing the first organ inside the lis
            """"Using the function from the second question in order to help us here"""
            if inner_product(vectors[i], vectors[j]) == 0:
                count += 1
        if inner_product(vectors[i], vectors[i]) == 0:
            num += 1
    return int(count / 2 - num / 2)

