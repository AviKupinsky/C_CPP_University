#############################################################
# FILE : hangman.py
# WRITER : Avi Kupinsky avikupinsky 318336070
# EXERCISE : intro2cs2  ex 4 2021
#############################################################

""""Were using hangman_helper file in order to help us with are function"""
from hangman_helper import*

# In this function were updating the pattern based on the letter we give
def update_word_pattern(word, pattern, letter):
    """
    Updating the patten if the latter is in the word
    :param letter: if the letter that's in the word
    :param pattern: to update it if the letter is in the word
    :param word: the word we are trying to gus
    :return: updating pattern if the letter is in the word
    """
    result = ""
    for i in range(len(word)):
        if letter == word[i]:
            result += letter
        else:
            result += pattern[i]
    return result


# In this function we are finding all the words the match the pattern
def filter_words_list(words, pattern, wrong_guess_lst):
    new_words = []
    for word in words:
        is_good = True
        if len(word) != len(pattern):  # If they're not in the same length
            continue
        for x in range(len(pattern)):
            if pattern[x] == "_":
                if word[x] in wrong_guess_lst or word[x] in pattern:  # if the letter is in wrong_guess_lst or guest it already
                    is_good = False
            elif pattern[x] != "_":
                if word[x] != pattern[x]:  # the letter in word should be in the same spot in pattern
                    is_good = False
        for l in range(len(wrong_guess_lst)):
            if wrong_guess_lst[l] in word:  # A letter we guest that was wrong is in a word
                is_good = False
        if is_good:
            new_words.append(word)
    return new_words


def run_single_game(words_list, score):
    """
    Using from hangman_helper for a few function like "words_list" and "get input"
    and "display_state" in order to help run a function of hanging man for one game
    :param words_list: getting a random word and trying to guess it
    :param score: you start with 10 points and trying to see how much you fish in the end of the game
    :return: It depends if you win or lose. If you win then it returns that you have won and you're score.
    if you didn't beet the game that you have lost/
    """
    word = get_random_word(words_list)  # using a function from hangman_helper
    pattern = "_" * len(word)
    wrong_guess_lst = []
    msg = 'Lets start playing'
    display_state(pattern, wrong_guess_lst, score, msg)

    """"In this section we put all the conditions in order to verify what input counts"""
    while "_" in pattern and score > 0:
        msg = "you're next move"
        x, y = get_input()
        if x == LETTER:
            if len(y) > 1 or not ('a' <= y <= 'z'):  # this is because we only want lower case letters
                msg = "this input is incorrect try again"
                display_state(pattern, wrong_guess_lst, score, msg)
                continue
            elif y in pattern or y in wrong_guess_lst:  # in the scenario that we have already tried this letter
                msg = "you have chosen this letter in the past, please try again"
                display_state(pattern, wrong_guess_lst, score, msg)
                continue
            score = score - 1
            if y in word:
                pattern = update_word_pattern(word, pattern, y)
                n = word.count(y)
                score = score + ((n * (n + 1)) // 2)
                if pattern == word:  # that means we have guessed the whole word
                    display_state(word, wrong_guess_lst, score, 'you won')
                    return score
            else:
                wrong_guess_lst.append(y)  # We add the letter to the wrong_guess_lst
                if score == 0:
                    display_state(pattern, wrong_guess_lst, score, word)
                    return score
            display_state(pattern, wrong_guess_lst, score, msg)
        if x == WORD:  # in the scenario that we have chosen a word
            score = score - 1
            if y == word:
                n = pattern.count('_')  # We count points on how many empty spaces we had
                pattern = word
                score = score + ((n * (n + 1)) // 2)
                display_state(pattern, wrong_guess_lst, score, 'you won')
                return score
            if score == 0:
                display_state(pattern, wrong_guess_lst, score, word)
                return score
            display_state(pattern, wrong_guess_lst, score, msg)
        if x == HINT:
            score = score - 1
            hint = []
            filtered_words = filter_words_list(words_list, pattern, wrong_guess_lst)
            k = len(filtered_words)
            if len(filtered_words) > HINT_LENGTH:
                for i in range(HINT_LENGTH):
                    hint.append(filtered_words[(i * k) // HINT_LENGTH])
            else:
                hint = filtered_words
            show_suggestions(hint)
            if score > 0:
                display_state(pattern, wrong_guess_lst, score, msg)
                continue
            if score == 0:
                display_state(pattern, wrong_guess_lst, score, word)
                return score
            display_state(pattern, wrong_guess_lst, score, msg)
    return score



# In this function we are asking the player if they would like to continue playing and how the game begins
def main():
    score = POINTS_INITIAL  # This is 10 points
    words_list = load_words("words.txt")
    num_of_games = 0
    while score > 0:
        num_of_games += 1
        score = run_single_game(words_list, score)
        if score == 0:  # In the scenario that he lost
            msg = f"Number of games you have played are {num_of_games} and the score is {score}/" \
                  f",do you want to play another game?"
            another_game = play_again(msg)
            if another_game:
                score = POINTS_INITIAL
                num_of_games = 0
                continue
            else:
                break
        msg = f"Number of games you have played are {num_of_games} and the score is {score}/" \
                  f",do you want to play another game?"
        another_game = play_again(msg)
        if another_game:
            continue
        else:
            break


