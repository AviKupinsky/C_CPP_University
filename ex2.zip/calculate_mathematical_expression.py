#############################################################
# FILE : ex 2.py
# WRITER : Avi Kuipnsky avikupinsky 318336070
# EXERCISE : intro2cs2 ex 2 2021
#############################################################


# In this function we are calculating between two random numbers in invoice operation

def calculate_mathematical_expression(n1, n2, string):
    """"Calculating the results of tew numbers in invoice operation """
    if n1 == 0 or n2 == 0:
        return None
    elif string == "+":
        return n1 + n2
    elif string == "-":
        return n1 - n2
    elif string == "/":
        return n1 / n2
    elif string == "*":
        return n1 * n2


# In this function we are taking the results of the function calculate_mathematical_expression
# and putting it into one string


def calculate_from_string(my_string):
    """"Taking the function calculate_mathematical_expression and processing it to one string"""
    problem_a = float(my_string.split()[0])
    problem_b = my_string.split()[1]
    problem_c = float(my_string.split()[2])
    return calculate_mathematical_expression(problem_a, problem_c, problem_b)






















