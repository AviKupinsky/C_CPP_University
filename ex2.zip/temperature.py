#############################################################
# FILE : ex 2.py
# WRITER : Avi Kuipnsky avikupinsky 318336070
# EXERCISE : intro2cs2 ex 2 2021
#############################################################


# In this function we are trying to find between 3 days if the temperature was higher or lower than the usual


def is_vormir_safe(tem, d1, d2, d3):
    """"Calculating if between the 3 days there are two of them that are higher than the average"""
    if tem < d1 and tem < d2:
        return True
    elif tem < d1 and tem < d3:
        return True
    elif tem < d2 and tem < d3:
        return True
    else:
        return False


