#############################################################
# FILE : ex 2.py
# WRITER : Avi Kuipnsky avikupinsky 318336070
# EXERCISE : intro2cs2 ex 2 2021
#############################################################


import math

# In this function we are using the Quadratic equation to find how many results we have to the equation


def quadratic_equation(a, b, c):
    """"Writing the algorithm for Quadratic equation"""
    if math.pow(b, 2) - 4 * a * c > 0:
        n1 = ((-b - math.sqrt(math.pow(b, 2) - 4 * a * c)) / (2 * a))
        n2 = ((-b + math.sqrt(math.pow(b, 2) - 4 * a * c)) / (2 * a))
        return n1, n2
    elif math.pow(b, 2) - 4 * a * c == 0:
        n1 = ((-b - math.sqrt(math.pow(b, 2) - 4 * a * c)) / (2 * a))
        n2 = ((-b + math.sqrt(math.pow(b, 2) - 4 * a * c)) / (2 * a))
        return n1, None
    else:
        return None, None

# In this function we are using quadratic_equation in order to print the actual results


def quadratic_equation_user_input():
    """""Transforming the strings into floats"""
    my_string = input("Insert coefficients a, b, and c:")
    problem_a = float(my_string.split()[0])
    problem_b = float(my_string.split()[1])
    problem_c = float(my_string.split()[2])
    if problem_a == 0:
        print(" The parameter 'a' may not equal 0")
    else:
        """"Using quadratic_equation, based on its results we print in this function"""
        (n1, n2) = quadratic_equation(problem_a, problem_b, problem_c)
        if n2 != None:
            print(" The equation has 2 solutions: " + str(n1) + " " + "and" + " " + str(n2))
        elif n1 != None:
            print(" The equation has 1 solution: " + str(n1))
        else:
            print(" The equation has no solutions")





















