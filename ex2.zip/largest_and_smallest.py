#############################################################
# FILE : ex 2.py
# WRITER : Avi Kuipnsky avikupinsky 318336070
# EXERCISE : intro2cs2 ex 2 2021
#############################################################


# In this function we are taking 3 parameters and finding between them the maximum and minimum

def largest_and_smallest(n1, n2, n3):
    """"Taking the parameters and finding the maximum and minimum"""
    if n1 >= n2 and n1 >= n3:
        max = n1
    elif n2 >= n1 and n2 >= n3:
        max = n2
    else:
        max = n3
    if n1 <= n2 and n1 <= n3:
        min = n1
    elif n2 <= n1 and n2 <= n3:
        min = n2
    else:
        min = n3
    return max, min

# Checking if function largest_and_smallest is working through boolean


def check_largest_and_smallest():
    """"Examples for function for largest_and_smallest"""
    if largest_and_smallest(17, 1, 6) == (17, 1) \
        and largest_and_smallest(1, 17, 6) == (17, 1) \
        and largest_and_smallest(1, 1, 2) == (2, 1) \
        and largest_and_smallest(-14, 4, 8) == (8, -14) \
        and largest_and_smallest(13.5, 5.3, 6.8) == (13.5, 5.3):
        """"The results will give us a boolean answer"""
        return True
    else:
        return False















