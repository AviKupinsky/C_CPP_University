#############################################################
# FILE : ex 2.py
# WRITER : Avi Kuipnsky avikupinsky 318336070
# EXERCISE : intro2cs2 ex 2 2021
#############################################################


import math

# In this function we are we are given numbers between 1-3 the function we calculate the shape area


def shape_area():
    """"Wanting to get input based on the number we give"""
    my_string = input("Choose shape (1=circle, 2=rectangle, 3=triangle): ")
    if my_string == "1":
        circle = input()
        """"Calculating the area of a circle"""
        return(math.pi * float(circle) ** 2)
    elif my_string == "2":
        rectangle1 = input()
        rectangle2 = input()
        """"Calculating the area of a rectangle"""
        return (float(rectangle1) * float(rectangle2))
    elif my_string == "3":
        triangle = input()
        """"Calculating the area of a triangle"""
        return ((math.sqrt(3)/4) * float(triangle) ** 2)
    else:
        return(None)













