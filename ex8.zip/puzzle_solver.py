from typing import List, Tuple, Set, Optional, Any
import copy


# We define the types of a partial picture and a constraint (for type checking).
Picture = List[List[int]]
Constraint = Tuple[int, int, int]


def max_seen_cells(picture: Picture, row: int, col: int) -> int:
    """
    the function gives the number we see its numbers based on the rows and col we got
    if its -1 we look at it if its wight
    :param picture: a list of lists
    :param row: num
    :param col: num
    :return: num
    """
    count = 0
    if picture[row][col] == 0:
        return count
    else:
        count += 1
    row_length = len(picture)
    col_length = len(picture[0])
    new_row = row - 1
    new_new_row = row + 1
    new_col = col - 1
    new_new_col = col + 1
    while new_row >= 0:
        if picture[new_row][col] != 0:
            count += 1
            new_row -= 1
        else:
            break
    while new_new_row < row_length:
        if picture[new_new_row][col] != 0:
            count += 1
            new_new_row += 1
        else:
            break
    while new_col >= 0:
        if picture[row][new_col] != 0:
            count += 1
            new_col -= 1
        else:
            break
    while new_new_col < col_length:
        if picture[row][new_new_col] != 0:
            count += 1
            new_new_col += 1
        else:
            break
    return count


def min_seen_cells(picture: Picture, row: int, col: int) -> int:
    """
    the function gives the number we see its numbers based on the rows and col we got
    if its -1 we look at it if its black
    :param picture: a list of lists
    :param row: num
    :param col: num
    :return: num
    """
    count = 0
    if picture[row][col] == 0 or picture[row][col] == -1:
        return count
    else:
        count += 1
    row_length = len(picture)
    col_length = len(picture[0])
    new_row = row - 1
    new_new_row = row + 1
    new_col = col - 1
    new_new_col = col + 1
    while new_row >= 0:
        if picture[new_row][col] == 1:
            count += 1
            new_row -= 1
        else:
            break
    while new_new_row < row_length:
        if picture[new_new_row][col] == 1:
            count += 1
            new_new_row += 1
        else:
            break
    while new_col >= 0:
        if picture[row][new_col] == 1:
            count += 1
            new_col -= 1
        else:
            break
    while new_new_col < col_length:
        if picture[row][new_new_col] == 1:
            count += 1
            new_new_col += 1
        else:
            break
    return count


def check_constraints(picture: Picture, constraints_set: Set[Constraint]) -> int:
    """
    we check if picture is current based on wear there is in the constraints_set
    :param picture: a list in lists
    :param constraints_set: Tuple[int, int, int]
    :return: 0, 1, 2
    """
    if not constraints_set:
        return 2
    check = 1
    for i in constraints_set:
        if min_seen_cells(picture, i[0], i[1]) == i[2] and max_seen_cells(picture, i[0], i[1]) == i[2]:
            continue
        if min_seen_cells(picture, i[0], i[1]) <= i[2] <= max_seen_cells(picture, i[0], i[1]):
            check = 2
            continue
        else:
            check = 0
            break
    return check


def starting_list(constraints_set: Set[Constraint], picture: Picture) -> None:
    """
    in this function we begin the list and checking if there is 0 are 1
    :param picture: a list in lists
    :param constraints_set: Tuple[int, int, int]
    :return: None
    """
    for i in constraints_set:
        if i[2] == 0:
            picture[i[0]][i[1]] = 0
        elif i[2] == 1:
            picture[i[0]][i[1]] = 1
            legnth_row = len(picture) - 1
            legnth_col = len(picture[0]) - 1
            if (i[0] - 1) >= 0:
                picture[(i[0] - 1)][i[1]] = 0
            if (i[0] + 1) <= legnth_row:
                picture[(i[0] + 1)][i[1]] = 0
            if (i[1] - 1) >= 0:
                picture[(i[0])][i[1] - 1] = 0
            if (i[1] + 1) <= legnth_col:
                picture[(i[0])][i[1] + 1] = 0


def first_finding_all_option(picture: Picture):
    """
    in this function all the -1 in the picture become 0
    :param picture: a list in lists
    :return: None
    """
    for i in range(len(picture)):
        for j in range(len(picture[0])):
            if picture[i][j] == -1:
                picture[i][j] = 0


def solve_puzzle(constraints_set: Set[Constraint], n: int, m: int) -> Optional[Picture]:
    """
    in this function we fine a picture that fits the constrainrs set
    :param constraints_set: Tuple[int, int, int]
    :param n: num
    :param m: num
    :return: Optional[Picture]
    """
    list = []
    for i in range(n):
        new_list = []
        for j in range(m):
            new_list.append(-1)
        list.append(new_list)
    starting_list(constraints_set, list)
    one_more = []
    for i in constraints_set:
        one_more.append(i)
    return first_helper_solving_puzzle(one_more, constraints_set, list, [], 0)


def getting_all_mines(picture: Picture, item: Tuple[int, int, int], num: int) -> list:
    """
    we fine were all the -1 are
    :param picture: a list in lists
    :param item: Tuple[int, int, int]
    :param num: int
    :return: list
    """
    if num < 0:
        return []
    new_list = []
    count = 0
    one = item[0] + 1
    tew = item[0] - 1
    three = item[1] + 1
    foure = item[1] - 1
    len_row = len(picture) - 1
    len_col = len(picture[0]) - 1
    while count != num:
        if one <= len_row:
            if picture[one][item[1]] == -1:
                new_list.append((one, item[1]))
                count += 1
                one += 1
            elif picture[one][item[1]] == 1:
                count += 1
            else:
                break
        else:
            break
    count = 0
    while count != num:
        if tew >= 0:
            if picture[tew][item[1]] == -1:
                new_list.append((tew, item[1]))
                count += 1
                tew -= 1
            elif picture[tew][item[1]] == 1:
                count += 1
            else:
                break
        else:
            break

    count = 0
    while count != num:
        if three <= len_col:
            if picture[item[0]][three] == -1:
                new_list.append((item[0], three))
                count += 1
                three += 1
            elif picture[item[0]][three] == 1:
                count += 1
            else:
                break
        else:
            break
    count = 0
    while count != num:
        if foure >= 0:
            if picture[item[0]][foure] == -1:
                new_list.append((item[0], foure))
                count += 1
                foure -= 1
            elif picture[item[0]][foure] == 1:
                count += 1
            else:
                break
        else:
            break
    return new_list


def another_check(new_num: int, param: tuple, picture: Picture) -> int:
    """
    we update the new_num
    :param new_num: int
    :param param: tuple
    :param picture: a list of lists
    :return: new_num
    """
    one = param[0] + 1
    tew = param[0] - 1
    three = param[1] + 1
    four = param[1] - 1
    len_row = len(picture) - 1
    len_col = len(picture[0]) - 1
    while one <= len_row and picture[one][param[1]] == 1:
        new_num -= 1
        one += 1
    while tew >= 0 and picture[tew][param[1]] == 1:
        new_num -= 1
        tew -= 1
    while three <= len_col and picture[param[0]][three] == 1:
        new_num -= 1
        three += 1
    while four >= 0 and picture[param[0]][four] == 1:
        new_num -= 1
        four -= 1
    return new_num


def first_helper_solving_puzzle(checking_list: list, constraints_set: Set[Constraint], picture: Picture, last_pic: Picture,  num: int):
    """
    we fine in the helper the correct  picture
    :param checking_list: list
    :param constraints_set: Tuple[int, int, int]
    :param picture: a list of lists
    :param last_pic: a list of lists
    :param num: int
    :return: picture are none
    """
    if num == len(checking_list):
        return picture
    if check_constraints(picture, {checking_list[num]}) == 0:
        return None
    if check_constraints(picture, {checking_list[num]}) == 1:
        return first_helper_solving_puzzle(checking_list, constraints_set, picture, last_pic, num + 1)
    elif check_constraints(picture, {checking_list[num]}) == 2:
        picture[checking_list[num][0]][checking_list[num][1]] = 1
        new_num = checking_list[num][2] - 1
        new_num = another_check(new_num, checking_list[num], picture)
        if new_num <= 0:
            first_helper_solving_puzzle(checking_list, constraints_set, picture, last_pic, num + 1)
        tuppl_list = getting_all_mines(picture, checking_list[num], new_num)
        for p in n_length_combo(tuppl_list, new_num):
            new_pic = copy.deepcopy(picture)
            for i in range(len(p)):
                new_pic[p[i][0]][p[i][1]] = 1
            last_pic = first_helper_solving_puzzle(checking_list, constraints_set, new_pic, last_pic, num + 1)
            if last_pic:
                if check_constraints(last_pic, constraints_set) != 0:
                    first_finding_all_option(new_pic)
                    return last_pic
            else:
                continue


def n_length_combo(lst: list, n: int) -> list:
    """
    in this function we fine all the combination there is
    :param lst: list
    :param n: n
    :return: a list of all the combination
    """
    if n == 0:
        return [[]]
    saving = []
    for i in range(0, len(lst)):
        m = lst[i]
        new_list = lst[i + 1:]
        for p in n_length_combo(new_list, n - 1):
            saving.append([m] + p)
    return saving


def how_many_solutions(constraints_set: Set[Constraint], n: int, m: int) -> int:
    """
    we fine all the possible there is
    :param constraints_set: Tuple[int, int, int]
    :param n: num
    :param m: num
    :return: number of all the there is
    """
    if not solve_puzzle(constraints_set, n, m):
        return 0
    if not constraints_set:
        new_num = (n*m)*(n*m)
        return new_num
    list = []
    for i in range(n):
        new_list = []
        for j in range(m):
            new_list.append(-1)
        list.append(new_list)
    starting_list(constraints_set, list)
    one_more = []
    for i in constraints_set:
        one_more.append(i)
    num = 0
    return second_helper_solving_puzzle(one_more, constraints_set, list, [], 0, num)


def all_options(new_pic: Picture, count: int, constraints_set: Set[Constraint], final: list) -> int:
    """
    we add to the count all the option there is
    :param new_pic: a list of lists
    :param count: num
    :param constraints_set: Tuple[int, int, int]
    :param final: list
    :return: count
    """
    new_list = []
    for i in range(len(new_pic)):
        for j in range(len(new_pic[0])):
            if new_pic[i][j] == -1:
                new_list.append((i, j))
    for j in range(1, (len(new_list) + 1)):
        for p in n_length_combo(new_list, j):
            last = copy.deepcopy(new_pic)
            for k in range(len(p)):
                last[p[k][0]][p[k][1]] = 0
                for i in range(len(last)):
                    for l in range(len(last[0])):
                        if last[i][l] == -1:
                            last[i][l] = 1
            if check_constraints(last, constraints_set) == 1 and p not in final:
                count += 1
                final.append(p)
    return count


def second_helper_solving_puzzle(checking_list: list, constraints_set: Set[Constraint], picture: Picture, last_pic: Picture,  num: int, count: int) -> Any:
    """
    we use the helper to fine all the options we got
    :param checking_list: list
    :param constraints_set: Tuple[int, int, int]
    :param picture: a list of lists
    :param last_pic: a list of lists
    :param num: int
    :param count: int
    :return: count
    """
    if num == len(checking_list):
        x = 0
        for i in range(len(picture)):
            for j in range(len(picture[0])):
                if picture[i][j] == -1:
                    x += 1
        if check_constraints(picture, constraints_set) == 1 and x == 0:
            return 1
        else:
            return picture
    if check_constraints(picture, {checking_list[num]}) == 0:
        return None
    if check_constraints(picture, {checking_list[num]}) == 1:
        return second_helper_solving_puzzle(checking_list, constraints_set, picture, last_pic, num + 1, count)
    elif check_constraints(picture, {checking_list[num]}) == 2:
        picture[checking_list[num][0]][checking_list[num][1]] = 1
        new_num = checking_list[num][2] - 1
        new_num = another_check(new_num, checking_list[num], picture)
        if new_num == 0:
            second_helper_solving_puzzle(checking_list, constraints_set, picture, last_pic, num + 1, count)
        tuppl_list = getting_all_mines(picture, checking_list[num], new_num)
        final = []
        for p in n_length_combo(tuppl_list, new_num):
            new_pic = copy.deepcopy(picture)
            for i in range(len(p)):
                new_pic[p[i][0]][p[i][1]] = 1
            last_pic = second_helper_solving_puzzle(checking_list, constraints_set, new_pic, last_pic, num + 1, count)
            if last_pic is None:
                continue
            if last_pic and num != 0:
                if isinstance(last_pic, int):
                    return last_pic
                if check_constraints(last_pic, constraints_set) != 0:
                    return last_pic
            elif last_pic and num == 0:
                if isinstance(last_pic, int):
                    return last_pic
                if check_constraints(last_pic, constraints_set) == 1:
                    num += 1
                elif check_constraints(last_pic, constraints_set) == 2:
                    count = all_options(last_pic, count, constraints_set, final)
                else:
                    continue
    if num == 0:
        return count


def generate_puzzle(picture: Picture) -> Set[Constraint]:
    """
    we fine the amount of tup we need in order to get to the picture we have
    :param picture: a list of lists
    :return: Set[Constraint]
    """
    set = {()}
    set.remove(())
    for i in range(len(picture)):
        for j in range(len(picture[0])):
            set.add((i, j, min_seen_cells(picture, i, j)))
            if solve_puzzle(set, len(picture), len(picture[0])) == picture and\
                    how_many_solutions(set, len(picture), len(picture[0])) == 1:
                break
        else:
            continue
        break
    old_set = copy.deepcopy(set)
    for i in old_set:
        new_set = copy.deepcopy(set)
        new_set.remove(i)
        if how_many_solutions(new_set, len(picture), len(picture[0])) == 1 and new_set:
            set = copy.deepcopy(new_set)
    return set

