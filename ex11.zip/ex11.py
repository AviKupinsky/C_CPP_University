#################################################################
# FILE : ex11
# WRITER :avikupinsky
# EXERCISE : intro2cs2 ex11 2021
# DESCRIPTION: A program making a tree and how to work with it
#################################################################
import itertools


class Node:
	"""
	This is a class Node were we get the data of the vertex and get the next wan
	depending if its positive_child or negative_child
	:param data: the information in the vertex
	:param positive_child: starts with None
	:param negative_child: starts with None
	"""
	def __init__(self, data, positive_child=None, negative_child=None):
		self.data = data
		self.positive_child = positive_child
		self.negative_child = negative_child


class Record:
	"""
	This is a class were we get the illness and symptoms
	:param illness: illness
	:param symptoms: symptoms
	"""
	def __init__(self, illness, symptoms):
		self.illness = illness
		self.symptoms = symptoms


def parse_data(filepath):
	"""
	in tis function we reed throw a file to fet the records witch have the illness and symptoms
	:param filepath: a file
	:returns records
	"""
	with open(filepath) as data_file:
		records = []
		for line in data_file:
			words = line.strip().split()
			records.append(Record(words[0], words[1:]))
		return records


class Diagnoser:
	"""
	This is a class were we get the root and fins all of its children
	:param tree: root
	"""
	def __init__(self, tree):
		self.root = tree

	def minimize(self, remove_empty=False):
		"""
		In this function we try to minimize the tree so if there are any points we don't need, we take them off
		:param remove_empty: its stars False
		:returns a better version of the tree
		"""
		parent = self.root
		new_root = self.root
		if remove_empty is False:
			self.root = self.rec_minimize(new_root, parent)
		if remove_empty is True:
			self.root = self.new_rec_minimize(self.root, parent)
		return self.root

	def rec_minimize(self, tree, parent):
		"""
		In this function we are using rec to find any points that we dont new
		:param parent: the tree we are going to do the changes on
		:param tree: the tree from the beginning to the end
		"""
		if tree.positive_child is not None and tree.negative_child is not None:
			positive = Diagnoser(tree.positive_child)
			negative = Diagnoser(tree.negative_child)
			if positive.all_illnesses() == negative.all_illnesses():
				if tree == parent.positive_child:
					parent.positive_child = tree.positive_child
				if tree == parent.negative_child:
					parent.negative_child = tree.negative_child
				self.rec_minimize(tree.positive_child, parent)
				self.rec_minimize(tree.negative_child, parent)
				if positive.all_illnesses() == negative.all_illnesses():
					if not self.paths_to_illness(None):
						parent = parent.positive_child
			else:
				if tree.positive_child is not None:
					self.rec_minimize(tree.positive_child, tree)
				if tree.negative_child is not None:
					self.rec_minimize(tree.negative_child, tree)

		return parent

	def new_rec_minimize(self, root, parent):
		"""
		Like rec_minimize this check if there is root. data that i Non and if there is we take it off the tree
		:param parent: the list we do the changes on
		:param root: the tree from the beginning to the end
		"""

		if root.positive_child is not None and root.negative_child is not None:
			positive = Diagnoser(root.positive_child)
			negative = Diagnoser(root.negative_child)
			if positive.all_illnesses() == negative.all_illnesses():
				if positive.all_illnesses() != []:
					if root == parent.positive_child:
						parent.positive_child = root.positive_child
					if root == parent.negative_child:
						parent.negative_child = root.positive_child
			if root.positive_child.data is None and root.negative_child.data is None:
				if root == parent.positive_child:
					parent.positive_child = root.positive_child
				if root == parent.negative_child:
					parent.negative_child = root.negative_child
			elif root.positive_child.data is not None and root.negative_child.data is None:
				if root == parent.positive_child:
					parent.positive_child = root.positive_child
				if root == parent.negative_child:
					parent.negative_child = root.positive_child
			elif root.positive_child.data is None and root.negative_child.data is not None:
				if root == parent.positive_child:
					parent.positive_child = root.negative_child
				if root == parent.negative_child:
					parent.negative_child = root.negative_child
			else:
				self.new_rec_minimize(root.positive_child, root)
				self.new_rec_minimize(root.negative_child, root)
				if root.positive_child.data is None and root.negative_child.data is not None:
					if parent == root:
						parent = root.negative_child
					if parent.positive_child == root:
						parent.positive_child = root.negative_child
					if parent.negative_child == root:
						parent.negative_child = root.negative_child
				if root.positive_child.data is not None and root.negative_child.data is None:
					if parent == root:
						parent = root.positive_child
					if parent.positive_child == root:
						parent.positive_child = root.positive_child
					if parent.negative_child == root:
						parent.negative_child = root.positive_child
				if root.positive_child.data is None and root.negative_child.data is None:
					if parent.positive_child == root:
						parent.positive_child = root.positive_child
					if parent.negative_child == root:
						parent.negative_child = root.positive_child
				if positive.all_illnesses() == negative.all_illnesses():
					parent = parent.positive_child
		elif root.positive_child is None and root.negative_child is not None:
			parent = root.negative_child
			return self.new_rec_minimize(root.negative_child, parent)
		elif root.positive_child is not None and root.negative_child is None:
			parent = root.positive_child
			return self.new_rec_minimize(root.positive_child, parent)
		return parent

	def diagnose(self, symptoms):
		"""
		This function we get a list of symptoms and based on the list we find out what illness it is
		:param symptoms: symptoms
		:returns roots data
		"""
		new_root = self.root
		rec = self.rec_diagnose(symptoms, new_root)
		return rec

	def rec_diagnose(self, symptoms, root):
		"""
		This function we are using rec in order to find the illness
		:param symptoms: symptoms
		:param root: a vertex
		:returns roots data
		"""
		if root.negative_child is None and root.positive_child is None:
			return root.data
		else:
			if root.data in symptoms:
				return self.rec_diagnose(symptoms, root.positive_child)
			if root.data not in symptoms:
				return self.rec_diagnose(symptoms, root.negative_child)

	def calculate_success_rate(self, records):
		"""
		This function we are calculating the amount of illness we have in the tree
		divided by the amount of illness we have
		:param records: a list of illness and symptoms
		:returns the amount of illness we have in the tree divided by the amount of illness we have
		"""
		try:
			lst_symptoms = []
			lst_illness = []
			for i in records:
				lst_illness.append(i.illness)
				lst_symptoms.append(i.symptoms)
			count = 0
			for j in range(len(lst_symptoms)):
				if lst_illness[j] == self.diagnose(lst_symptoms[j]):
					count += 1
			return count / len(lst_symptoms)
		except ValueError:
			print("The length of the records are 0")
		except ZeroDivisionError:
			print("You can't divide by zero")

	def all_illnesses(self):
		"""
		This function we get all of the data's of the leaf which are all the illnesses
		:returns a list of all the illnesses from the most common to the least
		"""
		data_lst = self.rec_data(self.root, [])
		amount_lst = []
		for i in data_lst:
			amount_lst.append(self.count_data_lst(data_lst, i))
		new_amount_lst = self.counting_elements(amount_lst)
		another_data_lst = self.sort_lst(new_amount_lst)
		final_data_lst = []
		for j in another_data_lst:
			final_data_lst.append(j[1])
		return final_data_lst

	def sort_lst(self, lst):
		"""
		This function we sort the list from top to bottom
		:param lst: al list
		:returns a sorted version of the list
		"""
		lst.sort(key=lambda k: k[0])
		return lst[::-1]

	def counting_elements(self, data):
		"""
		This function we delete items that are in the list more then once
		:param data: al list
		:returns a cleaner list
		"""
		for x in data:
			while data.count(x) > 1:
				data.remove(x)
				continue
		return data

	def count_data_lst(self, lst, x):
		"""
		This function we count the amount of an item is in a list
		:param lst: al list
		:param x: the item
		:returns tuple of how many times it was in the list and the item
		"""
		count = 0
		for ele in lst:
			if ele == x:
				count = count + 1
		return count, x

	def rec_data(self, root, data_lst):
		"""
		This function we use rec to get all of the data in every vertex
		:param root: a vertex
		:param data_lst: a list
		:returns a list of all the data in every vertex
		"""
		if root.negative_child is None and root.positive_child is None:
			if root.data is not None:
				data_lst.append(root.data)
		else:
			if root.negative_child is not None:
				self.rec_data(root.negative_child, data_lst)
			if root.positive_child is not None:
				self.rec_data(root.positive_child, data_lst)
		return data_lst

	def paths_to_illness(self, illness):
		"""
		This function we are finding the path in the tree to the illness
		:param illness: illness
		:returns a list of all the paths to get to the illness
		"""
		if illness not in self.all_illnesses():
			if illness is not None:
				return []
		paths_list = []
		self.rec_path_to_illness(illness, self.root, [], paths_list)
		return paths_list

	def rec_path_to_illness(self, illness, root, lst, final_lst):
		"""
		This function we use rec in order to find all the paths to the illness
		:param illness: illness
		:param root: a vertex
		:param lst: a list
		:param final_lst: the list that include all the paths
		"""
		if root.negative_child is None and root.positive_child is None:
			if root.data == illness:
				final_lst.append(lst)
			return
		else:
			if root.positive_child:
				self.rec_path_to_illness(illness, root.positive_child, lst + [True], final_lst)
			if root.negative_child:
				self.rec_path_to_illness(illness, root.negative_child, lst + [False], final_lst)


def build_tree(records, symptoms):
	"""
	In this function we build a tree with records based on the symptoms we give it
	:param records: The class records the includes symptoms and illnesses
	:param symptoms: a list of symptoms
	:returns: A class Diagnoser of the tree
	"""
	try:
		list_of_all_symptoms = list_symptoms_in_records(records)
		list_symptoms_in_every_illness = the_same_elements(records)
		symptoms = list(symptoms)
		element = symptoms.pop(0)
		root = Node(element)
		symptoms_to_leaf = []
		symptoms_not_to_leaf = []
		children(root, symptoms, list_of_all_symptoms, list_symptoms_in_every_illness,
				 symptoms_to_leaf, symptoms_not_to_leaf, records)
		diagnoser = Diagnoser(root)
		return diagnoser
	except TypeError:
		print("the item records is not from the class records or the item symptoms is not a string")


def finding_the_symptoms(records, yes, no):
	"""
	In this function we finding all the illness that much the leaf we are looking for
	:param records: The class records the includes symptoms and illnesses
	:param yes: a list of symptoms that are the way to the leaf
	:param no: a list of symptoms that are not the way tho the leaf
	:returns: A list of all the illness that much
	"""
	lst = []
	lst1 = []
	for i in records:
		for j in i.symptoms:
			if j in no:
				lst1.append(i.illness)
	for i in records:
		new_result = all(elem in i.symptoms for elem in yes)
		if new_result:
			if not no:
				lst.append(i)
			else:
				for j in no:
					if j not in i.symptoms:
						if i.illness not in lst1:
							lst.append(i)
	return lst


def organizing(lst, root):
	"""
	In this function we are checking just for that last illnesses if the items in the list have it
	:param lst: a list of all types of illnesses
	:param root: a list of symptoms including the last one
	:returns: a list that dos have all the items and a list that dos not have all the items
	"""
	new_list1 = []
	new_list2 = []
	for i in lst:
		result = all(elem in i.symptoms for elem in root)
		if result:
			new_list1.append(i.illness)
		else:
			new_list2.append(i.illness)
	return new_list1, new_list2


def last_childeren(root, list1, list2):
	"""
	In this function we finding the illness to the data
	:param root: the one before the leaf
	:param list1: a list of symptoms with the final symptom
	:param list2: a list of symptoms without the final symptom
	"""
	all_illness1 = []
	all_illness2 = []
	if len(list1) != 0:
		for illness in list1:
			all_illness1.append(count_data_lst(list1, illness))
		counting_elements(all_illness1)
		sort_lst(all_illness1)
		res1 = max(all_illness1, key=lambda i: i[1])[0]
		root.positive_child = Node(res1)
	if len(list2) != 0:
		for illness in list2:
			all_illness2.append(count_data_lst(list2, illness))
		counting_elements(all_illness2)
		sort_lst(all_illness2)
		res2 = max(all_illness2, key=lambda i: i[1])[0]
		root.negative_child = Node(res2)


def children(root, symptoms, list_symptoms, prime_list, symptoms_to_leaf, symptoms_not_to_leaf, records):
	"""
	In this function we are using rec to get to the leaf iwth the right illness
	:param root: the item we are checking at this point
	:param symptoms: symptoms
	:param list_symptoms: a list of all the symptoms we have
	:param prime_list: a list of the symptoms what every single illness hase
	:param symptoms_to_leaf: symptoms to get to the leaf
	:param symptoms_not_to_leaf: symptoms not on the way to the leaf
	:param records: The class records the includes symptoms and illnesses
	:returns: None
	"""
	if len(symptoms) == 0:
		lst = finding_the_symptoms(records, symptoms_to_leaf, symptoms_not_to_leaf)
		if len(lst) == 0:
			root.data = None
			return
		new_list1, new_list2 = organizing(lst, symptoms_to_leaf + [root.data])
		last_childeren(root, new_list1, new_list2)
		return

	else:
		element = symptoms.pop(0)
		if root.data in prime_list:
			root.positive_child = Node(element)
			children(root.positive_child, symptoms, list_symptoms, prime_list,
					symptoms_to_leaf + [root.data], symptoms_not_to_leaf, records)
		elif root.data not in list_symptoms:
			root.negative_child = Node(element)
			children(root.negative_child, symptoms, list_symptoms, prime_list,
					symptoms_to_leaf, symptoms_not_to_leaf + [root.data], records)
		else:
			root.positive_child = Node(element)
			root.negative_child = Node(element)
			children(root.positive_child, symptoms, list_symptoms, prime_list,
					symptoms_to_leaf + [root.data], symptoms_not_to_leaf, records)
			children(root.negative_child, symptoms, list_symptoms, prime_list,
					symptoms_to_leaf, symptoms_not_to_leaf + [root.data], records)


def the_same_elements(records):
	"""
	In this function we want to get the symptoms that are in every illness
	:param records: The class records the includes symptoms and illnesses
	:returns: a list of the symptoms in every illness
	"""
	list = []
	new_lst = []
	new_new_list = []
	for i in records:
		list.append(i.symptoms)
	for i in list:
		for j in i:
			new_lst.append(j)
	for i in new_lst:
		if new_lst.count(i) == len(records):
			new_new_list.append(i)
	return new_new_list


def list_symptoms_in_records(records):
	"""
	In this function we want to get the symptoms that are in all the illness
	:param records: The class records the includes symptoms and illnesses
	:returns: a list of the symptoms in all the illness
	"""
	list = []
	new_lst = []
	for i in records:
		list.append(i.symptoms)
	for i in list:
		for j in i:
			new_lst.append(j)
	return new_lst


def count_data_lst(lst, x):
	"""
	This function we count the amount of an item is in a list
	:param lst: al list
	:param x: the item
	:returns tuple of how many times it was in the list and the item
	"""
	count = 0
	for ele in lst:
		if ele == x:
			count = count + 1
	return x, count


def counting_elements(data):
	"""
	This function we delete items that are in the list more then once
	:param data: al list
	:returns a cleaner list
	"""
	for x in data:
		while data.count(x) > 1:
			data.remove(x)
			continue
	return data


def sort_lst(lst):
	"""
	This function we sort the list from top to bottom
	:param lst: al list
	:returns a sorted version of the list
	"""
	lst.sort(key=lambda k: k[0])
	return lst[::-1]


def optimal_tree(records, symptoms, depth):
	"""
	In this function we finding the most successful tree between the length of depth throw symptoms
	:param records: The class records the includes symptoms and illnesses
	:param records: The class records the includes symptoms and illnesses
	:param symptoms: a list of symptoms
	:param depth:  the length
	:returns:  A class Diagnoser of the tree the best ine
	"""
	try:
		lst = list(itertools.combinations(symptoms, depth))
		all_trees = []
		for i in lst:
			all_trees.append(build_tree(records, i))
		end = []
		for j in all_trees:
			end.append((j, j.calculate_success_rate(records)))
		res1 = max(end, key=lambda i: i[1])[0]
		return res1
	except ValueError:
		print("depth is bigger then the actual length in symptoms")
	except TypeError:
		print("the item records is not from the class records or the item symptoms is not a string")


